# FURY Network

A gaming-first FURY Network dashboard built as a static site for Cloudflare Workers.

## Files
- `public/index.html` — site structure
- `public/style.css` — full visual system
- `public/script.js` — navigation and demo data
- `wrangler.toml` — Cloudflare Workers static-assets configuration

## Deploy
Connect this repository to Cloudflare Workers and use:

Build command: leave blank
Deploy command: `npx wrangler deploy`

The site is intentionally front-end only for the first version. Real Discord links, live game APIs, rankings, authentication, and market data can be connected later.
