const sections = [...document.querySelectorAll(".page-section")];
const navItems = [...document.querySelectorAll(".nav-item")];
const pageName = document.getElementById("pageName");
const toast = document.getElementById("toast");

function showToast(message){
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(window.__toast);
  window.__toast = setTimeout(()=>toast.classList.remove("show"), 2600);
}

function navigate(id){
  sections.forEach(s=>s.classList.toggle("active-section", s.id===id));
  navItems.forEach(n=>n.classList.toggle("active", n.dataset.section===id));
  pageName.textContent = id.toUpperCase();
  window.scrollTo({top:0,behavior:"smooth"});
  history.replaceState(null,"","#"+id);
}

navItems.forEach(item=>{
  item.addEventListener("click", e=>{
    e.preventDefault();
    navigate(item.dataset.section);
  });
});

document.querySelectorAll("[data-toast]").forEach(btn=>{
  btn.addEventListener("click",()=>showToast(btn.dataset.toast));
});

document.getElementById("focusSearch").addEventListener("click",()=>{
  navigate("dashboard");
  setTimeout(()=>document.getElementById("searchInput").focus(),100);
});

document.getElementById("searchInput").addEventListener("keydown", e=>{
  if(e.key==="Enter" && e.target.value.trim()) showToast(`Searching the FURY network for "${e.target.value.trim()}"`);
});

document.querySelectorAll("#discordBtn,#discordBtn2").forEach(btn=>{
  btn.addEventListener("click",()=>showToast("Add your FURY Discord invite link in script.js"));
});
document.getElementById("applyBtn").addEventListener("click",()=>showToast("Recruitment form coming next"));

const games = [
  ["KINTARA","MMO · PVP","FURY operations and guild warfare."],
  ["WARFRAME","CO-OP · ACTION","Squads, builds and missions."],
  ["MINECRAFT","SURVIVAL · PVP","Servers, builds and communities."],
  ["ROBLOX","COMMUNITY","Player-made worlds and groups."],
  ["BLOODSTRIKE","FPS · PVP","Competitive squads and rankings."],
  ["CODM","FPS · MOBILE","Competitive mobile gaming."]
];
const guilds = [
  ["FURY","9,842","248 wins","Primary network guild"],
  ["GOLD","9,114","231 wins","Established alliance"],
  ["ROT","8,760","219 wins","Rival guild"],
  ["MOSSAD","7,921","193 wins","Competitive guild"],
  ["RED ARMY","6,430","161 wins","Community guild"]
];
const projects = [
  ["SolForge","Trading / analytics","WATCHING","Community market dashboard concept."],
  ["FURY Network","Gaming platform","BUILDING","The website you are currently viewing."],
  ["Atlas Imperium","Strategy","CONCEPT","Large-scale country strategy prototype."]
];
const markets = [
  ["SolForge","$SOLFORGE","$—","—","Community project"],
  ["FURY","FURY","—","—","Network ecosystem"],
  ["Mango","$MANGOO","—","—","Community token project"]
];

function fillCards(target, data, type){
  const el=document.getElementById(target);
  el.innerHTML=data.map((x,i)=>`
    <article class="${type==="market"?"market-card":"info-card"}">
      <span class="tag">${type==="game"?"GAME":type==="guild"?"GUILD":"PROJECT"}</span>
      <div class="big">${x[0]}</div>
      <p>${type==="game"?x[1]:type==="guild"?`${x[1]} points · ${x[2]}`:x[1]}</p>
      <p>${type==="guild"?x[3]:x[2]||""}</p>
    </article>`).join("");
}
fillCards("gamesGrid",games,"game");
fillCards("guildsGrid",guilds,"guild");
fillCards("projectsGrid",projects,"project");

document.getElementById("marketGrid").innerHTML=markets.map(x=>`
  <article class="market-card"><span class="tag">WATCHLIST</span><div class="big">${x[0]}</div>
  <p>${x[1]} · ${x[4]}</p><p class="change">DATA PENDING</p></article>`).join("");

const rankData=[
 ["01","FURY","9,842","248","98%"],
 ["02","GOLD","9,114","231","94%"],
 ["03","ROT","8,760","219","91%"],
 ["04","MOSSAD","7,921","193","87%"],
 ["05","RED ARMY","6,430","161","83%"],
 ["06","KINGS OF KINTARA","6,018","149","79%"]
];
document.getElementById("rankingTable").innerHTML=
`<div class="large-row header"><span>#</span><span>GUILD</span><span>POINTS</span><span>WINS</span><span>ACTIVITY</span></div>`+
rankData.map(r=>`<div class="large-row"><span>${r[0]}</span><strong>${r[1]}</strong><b>${r[2]}</b><span>${r[3]}</span><span>${r[4]}</span></div>`).join("");

const events=[
 ["12 OCT","FURY WAR ROOM","Guild briefing · 20:00 IST"],
 ["18 OCT","KINTARA PVP NIGHT","Open network event"],
 ["24 OCT","GUILD SHOWDOWN","Registration opens soon"],
 ["31 OCT","FURY NETWORK NIGHT","Community games"]
];
document.getElementById("eventCards").innerHTML=events.map(e=>`
 <article class="event-card"><span class="tag">${e[0]}</span><h2 style="font:18px 'Archivo Black';margin:22px 0 8px">${e[1]}</h2><p>${e[2]}</p></article>`).join("");

const initial = location.hash.slice(1);
if(initial && document.getElementById(initial)) navigate(initial);
